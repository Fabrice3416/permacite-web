// Handles auth token refresh and storage sync from the web app

const WEB_APP = 'https://permacite-web-mpqx.vercel.app'

// ── Listen for auth messages from the web app ──────────────────────────────
// The web app posts a message via chrome.runtime.sendMessage after login
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  // externally_connectable in manifest already restricts which origins can reach here
  const origin = sender.url ? new URL(sender.url).origin : ''
  const allowed = origin === 'http://localhost:3000' || origin === 'https://permacite-web-mpqx.vercel.app'
  if (!allowed) {
    sendResponse({ ok: false, error: 'unauthorized' })
    return true
  }

  if (message.type === 'PING') {
    sendResponse({ ok: true })
    return true
  }

  if (message.type === 'AUTH_SUCCESS') {
    chrome.storage.local.set({
      accessToken:  message.accessToken,
      refreshToken: message.refreshToken,
      userId:       message.userId,
      userEmail:    message.userEmail
    }, () => {
      sendResponse({ ok: true })
    })
    return true
  }

  if (message.type === 'AUTH_LOGOUT') {
    chrome.storage.local.clear(() => {
      sendResponse({ ok: true })
    })
    return true
  }

  sendResponse({ ok: false, error: 'unknown_type' })
  return true
})

// ── Alarm: refresh token every 50 minutes before it expires ───────────────
chrome.alarms.create('token-refresh', { periodInMinutes: 50 })

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'token-refresh') return

  const { refreshToken } = await chrome.storage.local.get('refreshToken')
  if (!refreshToken) return

  try {
    const res = await fetch(`${WEB_APP}/api/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken })
    })

    if (!res.ok) {
      // Refresh failed — clear session, user must log in again
      await chrome.storage.local.clear()
      return
    }

    const { accessToken, newRefreshToken } = await res.json()
    await chrome.storage.local.set({
      accessToken,
      refreshToken: newRefreshToken
    })
  } catch {
    // Network error — keep existing token, retry next alarm
  }
})
