const API_BASE    = 'https://permacite-web-mpqx.vercel.app'
const WEB_APP     = 'https://permacite-web-mpqx.vercel.app'
const POSTHOG_KEY  = 'phc_n4DTgPPKopPd8quMMVVjvQSqmS4ax0HNCczq2Jkg41U'
const POSTHOG_HOST = 'https://us.i.posthog.com'
// TODO: confirmer le store slug dans LS Settings → Store avant le déploiement
const UPGRADE_URL = 'https://formationdevia.lemonsqueezy.com/checkout/buy/1703519'

// ── i18n helper ────────────────────────────────────────────────────────────
function t(key, substitutions) {
  return chrome.i18n.getMessage(key, substitutions) || key
}

function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n
    const msg = t(key)
    if (msg) el.textContent = msg
  })
}

// ── PostHog — direct HTTP API (no SDK, no supply-chain risk) ───────────────
async function capture(event, props = {}) {
  const { userId } = await chrome.storage.local.get('userId')
  fetch(`${POSTHOG_HOST}/capture/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      api_key: POSTHOG_KEY,
      event,
      distinct_id: userId || 'anonymous',
      properties: { ...props, $lib: 'permacite-extension' }
    })
  }).catch(() => {}) // analytics must never break the app
}

// ── View manager ───────────────────────────────────────────────────────────
const VIEWS = ['auth', 'main', 'loading', 'result', 'paywall', 'error']

function showView(name) {
  VIEWS.forEach(v => {
    document.getElementById(`view-${v}`).classList.add('hidden')
  })
  document.getElementById(`view-${name}`).classList.remove('hidden')
}

// ── Auth ───────────────────────────────────────────────────────────────────
async function getSession() {
  const { accessToken, refreshToken, userId, userEmail } =
    await chrome.storage.local.get(['accessToken', 'refreshToken', 'userId', 'userEmail'])
  return { accessToken, refreshToken, userId, userEmail }
}

// Fallback: if sendMessage failed, read tokens from the open localhost:3000 tab
async function recoverPendingAuth() {
  try {
    const tabs = await chrome.tabs.query({ url: 'http://localhost:3000/*' })
    if (!tabs.length) return false
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        const raw = localStorage.getItem('permacite_pending_auth')
        if (raw) localStorage.removeItem('permacite_pending_auth')
        return raw
      }
    })
    const raw = results[0]?.result
    if (!raw) return false
    const { at, rt, uid, ue } = JSON.parse(raw)
    if (!at) return false
    await chrome.storage.local.set({ accessToken: at, refreshToken: rt, userId: uid, userEmail: ue })
    return true
  } catch {
    return false
  }
}

// ── Quota helpers ──────────────────────────────────────────────────────────
function updateQuotaBadge(used, max) {
  document.getElementById('quota-used').textContent = used
  const sep   = document.getElementById('quota-limit-sep')
  const maxEl = document.getElementById('quota-max')
  if (max === null || max === undefined) {
    sep.style.display   = 'none'
    maxEl.style.display = 'none'
  } else {
    maxEl.textContent = max
    document.getElementById('quota-badge').style.color = used >= max ? '#dc2626' : '#64748b'
  }
}

// ── Zotero detection ───────────────────────────────────────────────────────
async function detectZotero() {
  try {
    const res = await fetch('http://localhost:23119/zotero/items?limit=1', {
      signal: AbortSignal.timeout(500)
    })
    return res.ok
  } catch {
    return false
  }
}

async function pushToZotero(item) {
  const zoteroItem = {
    itemType: 'webpage',
    title: item.title,
    url: item.archiveUrl,
    accessDate: new Date().toISOString().split('T')[0],
    websiteTitle: item.siteName,
    abstractNote: item.quote || ''
  }
  const res = await fetch('http://localhost:23119/zotero/items', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify([zoteroItem])
  })
  return res.ok
}

// ── Copy to clipboard ──────────────────────────────────────────────────────
function setupCopyButtons() {
  document.querySelectorAll('.btn-copy').forEach(btn => {
    btn.textContent = t('copy_btn')
    btn.addEventListener('click', async () => {
      const targetId = btn.dataset.target
      const text = document.getElementById(targetId).textContent
      await navigator.clipboard.writeText(text)
      btn.textContent = t('copied_btn')
      btn.classList.add('copied')
      setTimeout(() => {
        btn.textContent = t('copy_btn')
        btn.classList.remove('copied')
      }, 2000)
      capture('citation_copied', { style: targetId.includes('apa') ? 'APA' : 'MLA' })
    })
  })
}

// ── Session expired — clear tokens and show login ──────────────────────────
async function handleSessionExpired() {
  await chrome.storage.local.clear()
  document.getElementById('btn-login').href = `${WEB_APP}/login?source=extension&ext_id=${chrome.runtime.id}`
  document.getElementById('btn-login').textContent = t('login_cta')
  // Show a brief message before switching to auth view
  const authMsg = document.querySelector('#view-auth p') || document.createElement('p')
  authMsg.textContent = t('session_expired') || 'Your session has expired. Please sign in again.'
  authMsg.style.cssText = 'color:#dc2626;font-size:13px;margin-bottom:8px'
  const loginBtn = document.getElementById('btn-login')
  loginBtn.parentNode.insertBefore(authMsg, loginBtn)
  showView('auth')
}

// ── Main capture flow ──────────────────────────────────────────────────────
async function runCapture(tab, accessToken) {
  showView('loading')
  const start = Date.now()

  try {
    const res = await fetch(`${API_BASE}/api/capture`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify({ url: tab.url })
    })

    if (res.status === 401) {
      await handleSessionExpired()
      return
    }

    const data = await res.json()

    if (res.status === 402) {
      capture('paywall_hit', { citations_used: data.used })
      showPaywall()
      return
    }

    if (!res.ok) throw new Error(data.error || t('error_generic'))

    const elapsed = Date.now() - start
    capture('source_archived', {
      citation_style: 'APA+MLA',
      archive_success: true,
      time_ms: elapsed,
      zotero_synced: false
    })

    showResult(data)
  } catch (err) {
    capture('capture_error', { message: err.message })
    showError(err.message)
  }
}

// ── Show result view ───────────────────────────────────────────────────────
let lastResult = null

function showResult(data) {
  lastResult = data

  document.getElementById('citation-apa').textContent = data.citationApa
  document.getElementById('citation-mla').textContent = data.citationMla

  const archiveLink = document.getElementById('archive-link')
  archiveLink.href = data.archiveUrl
  archiveLink.textContent = t('view_archive')

  const btnZotero = document.getElementById('btn-zotero')
  if (data.zoteroAvailable) {
    btnZotero.classList.remove('hidden')
  }

  showView('result')
}

function showPaywall() {
  document.getElementById('btn-upgrade').href = UPGRADE_URL
  showView('paywall')
}

function showError(msg) {
  document.getElementById('error-msg').textContent = msg
  showView('error')
}

// ── Init ───────────────────────────────────────────────────────────────────
async function init() {
  applyI18n()
  setupCopyButtons()

  // ── Check if we just returned from auth (tokens in URL params) ──────────
  const urlParams = new URLSearchParams(window.location.search)
  const freshToken = urlParams.get('at')
  if (freshToken) {
    await chrome.storage.local.set({
      accessToken:  freshToken,
      refreshToken: urlParams.get('rt') ?? '',
      userId:       urlParams.get('uid') ?? '',
      userEmail:    urlParams.get('ue') ?? ''
    })
    // Clean the URL so tokens don't persist in history
    window.history.replaceState({}, '', window.location.pathname)
  }

  let { accessToken, userId, userEmail } = await getSession()

  if (!accessToken) {
    // sendMessage might have failed — try reading tokens directly from the web app tab
    const recovered = await recoverPendingAuth()
    if (recovered) {
      const session = await getSession()
      accessToken = session.accessToken
      userId = session.userId
      userEmail = session.userEmail
    }
  }

  if (!accessToken) {
    document.getElementById('btn-login').href = `${WEB_APP}/login?source=extension&ext_id=${chrome.runtime.id}`
    document.getElementById('btn-login').textContent = t('login_cta')
    showView('auth')
    capture('extension_opened', { state: 'unauthenticated' })
    return
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

  // Truncate URL for display
  const urlEl = document.getElementById('current-url')
  urlEl.textContent = tab.url

  // Check Zotero in background
  detectZotero().then(found => {
    if (found) {
      document.getElementById('zotero-notice').classList.remove('hidden')
    }
  })

  // Fetch quota from server — also validates token freshness
  try {
    const res = await fetch(`${API_BASE}/api/quota`, {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    })
    if (res.status === 401) {
      await handleSessionExpired()
      return
    }
    if (res.ok) {
      const { used, max } = await res.json()
      updateQuotaBadge(used, max)
    }
  } catch { /* non-blocking */ }

  showView('main')
  capture('extension_opened', { state: 'authenticated', user_id: userId })

  // ── Capture button ──
  document.getElementById('btn-capture').addEventListener('click', () => {
    runCapture(tab, accessToken)
  })

  // ── New capture button ──
  document.getElementById('btn-new').addEventListener('click', () => {
    showView('main')
  })

  // ── Zotero sync button ──
  document.getElementById('btn-zotero').addEventListener('click', async () => {
    if (!lastResult) return
    const ok = await pushToZotero(lastResult)
    if (ok) {
      document.getElementById('btn-zotero').textContent = t('zotero_synced_ok')
      document.getElementById('btn-zotero').disabled = true
      capture('source_archived', { zotero_synced: true })
    }
  })

  // ── Retry button ──
  document.getElementById('btn-retry').addEventListener('click', () => {
    runCapture(tab, accessToken)
  })
}

document.addEventListener('DOMContentLoaded', init)
